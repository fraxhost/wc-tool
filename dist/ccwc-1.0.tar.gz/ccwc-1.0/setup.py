from setuptools import setup

setup(
    name='ccwc',
    version='1.0',
    packages=['wc-tool'], # Specify the main module directly
    package_dir={'wc-tool': 'src'}, # Tell setup tools to look in the src/ folder
    entry_points={
        'console_scripts': [
            'ccwc=main:main' # Entry point pointing to main.py in src/
        ]
    },
    install_requires=[
        # Any dependencies your tool needs
    ],
    test_suite='tests'
)